-- Simple schema for MVP
CREATE TABLE IF NOT EXISTS farms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text,
  latitude double precision,
  longitude double precision,
  area_ha numeric,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS planting_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  field_id uuid,
  crop text,
  planting_date date,
  expected_harvest_date date,
  status text,
  created_at timestamptz DEFAULT now()
);
