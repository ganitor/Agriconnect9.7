require('dotenv').config();
const express = require('express');
const cors = require('cors');
const knex = require('knex');

const db = knex({
  client: 'pg',
  connection: process.env.DATABASE_URL
});

const app = express();
app.use(cors());
app.use(express.json());

app.get('/', (req, res) => res.json({status: 'AgriConnect backend running'}));

// Simple health route
app.get('/api/v1/health', (req, res) => res.json({ok: true}));

// Farms CRUD (in-memory fallback if DB not ready)
app.get('/api/v1/farms', async (req, res) => {
  try {
    const rows = await db.select('*').from('farms').limit(100);
    res.json(rows);
  } catch (e) {
    // fallback stub
    res.json([{id: 'stub-farm-1', name: 'Demo Farm', latitude: -1.2921, longitude: 36.8219}]);
  }
});

app.post('/api/v1/farms', async (req, res) => {
  const { name, latitude, longitude, area_ha } = req.body;
  try {
    const [row] = await db('farms').insert({name, latitude, longitude, area_ha}).returning('*');
    res.status(201).json(row);
  } catch (e) {
    // return stub
    res.status(201).json({id: 'stub-created', name, latitude, longitude, area_ha});
  }
});

// Planting records (minimal)
app.post('/api/v1/planting-records', async (req, res) => {
  const { field_id, crop, planting_date, expected_harvest_date } = req.body;
  try {
    const [row] = await db('planting_records').insert({field_id, crop, planting_date, expected_harvest_date}).returning('*');
    res.status(201).json(row);
  } catch (e) {
    res.status(201).json({id: 'stub-pr', field_id, crop, planting_date, expected_harvest_date});
  }
});

// Weather proxy
const axios = require('axios');
app.get('/api/v1/weather/current', async (req, res) => {
  const { lat, lon } = req.query;
  if (!process.env.WEATHER_API_KEY) return res.status(500).json({error: 'WEATHER_API_KEY not set in server'});
  try {
    const r = await axios.get('https://api.openweathermap.org/data/2.5/weather', {
      params: { lat, lon, appid: process.env.WEATHER_API_KEY, units: 'metric' }
    });
    res.json(r.data);
  } catch (e) {
    res.status(500).json({error: 'weather fetch failed', details: e.message});
  }
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Backend listening on ${PORT}`));
