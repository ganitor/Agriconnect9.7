import React, {useEffect, useState} from 'react'
import axios from 'axios'
import { Typography, TextField, Button, Stack, Paper } from '@mui/material'

export default function Farms(){
  const [farms,setFarms] = useState([])
  const [form,setForm] = useState({name:'', latitude:'', longitude:'', area_ha:''})
  useEffect(()=> fetchFarms(),[])
  function fetchFarms(){
    axios.get('/api/v1/farms').then(r=> setFarms(r.data)).catch(()=>{})
  }
  function create(){
    axios.post('/api/v1/farms', form).then(()=> { setForm({name:'', latitude:'', longitude:'', area_ha:''}); fetchFarms()})
  }
  return (
    <div>
      <Typography variant="h5" gutterBottom>Farms</Typography>
      <Paper sx={{p:2, mb:2}}>
        <Stack spacing={2}>
          <TextField label="Name" value={form.name} onChange={e=> setForm({...form, name: e.target.value})} />
          <TextField label="Latitude" value={form.latitude} onChange={e=> setForm({...form, latitude: e.target.value})} />
          <TextField label="Longitude" value={form.longitude} onChange={e=> setForm({...form, longitude: e.target.value})} />
          <TextField label="Area (ha)" value={form.area_ha} onChange={e=> setForm({...form, area_ha: e.target.value})} />
          <Button variant="contained" onClick={create}>Create Farm</Button>
        </Stack>
      </Paper>

      <Paper sx={{p:2}}>
        <Typography variant="h6">Existing</Typography>
        <pre>{JSON.stringify(farms, null, 2)}</pre>
      </Paper>
    </div>
  )
}
