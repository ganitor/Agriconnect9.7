import React, {useEffect, useState} from 'react'
import axios from 'axios'
import { Typography, Paper } from '@mui/material'

export default function Dashboard(){
  const [status,setStatus] = useState(null)
  useEffect(()=> {
    axios.get('/api/v1/health')
      .then(r=> setStatus(r.data))
      .catch(e=> setStatus({error: e.message}))
  },[])
  return (
    <Paper sx={{p:2}}>
      <Typography variant="h5">Dashboard</Typography>
      <pre>{JSON.stringify(status, null, 2)}</pre>
      <Typography variant="body2">This is a minimal scaffold. Use the Farms page to add demo farms.</Typography>
    </Paper>
  )
}
