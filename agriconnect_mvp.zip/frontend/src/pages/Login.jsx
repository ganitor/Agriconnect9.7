import React from 'react'
import { Typography, Paper } from '@mui/material'

export default function Login(){
  return (
    <Paper sx={{p:2}}>
      <Typography variant="h5">Login</Typography>
      <Typography variant="body2">Authentication placeholder (implement real auth).</Typography>
    </Paper>
  )
}
