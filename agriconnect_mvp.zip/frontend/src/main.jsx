import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import { CssBaseline, AppBar, Toolbar, Typography, Container, Button } from '@mui/material'
import Dashboard from './pages/Dashboard'
import Farms from './pages/Farms'
import Login from './pages/Login'

function App(){
  return (
    <>
      <CssBaseline />
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" sx={{flexGrow:1}}>AgriConnect MVP</Typography>
          <Button color="inherit" component={Link} to="/farms">Farms</Button>
          <Button color="inherit" component={Link} to="/login">Login</Button>
        </Toolbar>
      </AppBar>
      <Container sx={{mt:4}}>
        <Routes>
          <Route path="/" element={<Dashboard/>} />
          <Route path="/farms" element={<Farms/>} />
          <Route path="/login" element={<Login/>} />
        </Routes>
      </Container>
    </>
  )
}

createRoot(document.getElementById('root')).render(
  <BrowserRouter>
    <App/>
  </BrowserRouter>
)
